<html>
<body>
	<h1>Stock Manager Advance</h1>
	<p>We have reset the password for <?php echo $identity;?></p>
    <p>&nbsp;</p>
    <p>Your new password is: <?php echo $new_password;?></p>
    <p>&nbsp;</p>
    <p>Thank you!</p>
    <p>&nbsp;</p>
    <p>This is system generated email and replying this email will go nowhere. If you have any questions, Please contact the administrtor.</p>
    
</body>
</html>