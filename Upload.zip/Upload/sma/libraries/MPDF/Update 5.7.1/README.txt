Upgrading
============

To upgrade from mPDF 5.7 to 5.7.1, simply upload the 3 files to their corresponding folders, overwriting files as required.

