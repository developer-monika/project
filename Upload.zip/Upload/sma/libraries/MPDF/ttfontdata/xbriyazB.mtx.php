<?php
$name='XBRiyaz-Bold';
$type='TTF';
$desc=array (
  'Ascent' => 1123,
  'Descent' => -391,
  'CapHeight' => 720,
  'Flags' => 262148,
  'FontBBox' => '[-391 -849 1633 1274]',
  'ItalicAngle' => 0,
  'StemV' => 165,
  'MissingWidth' => 605,
);
$up=-278;
$ut=29;
$ttffile='D:/wamp/www/sma3/sma/libraries/MPDF/ttfonts/XB RiyazBd.ttf';
$TTCfontID='0';
$originalsize=1159192;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='xbriyazB';
$panose=' 0 0 2 0 8 3 8 0 0 2 0 4';
$haskerninfo=false;
$unAGlyphs=true;
?>