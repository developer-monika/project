<?php
$name='XBRiyaz';
$type='TTF';
$desc=array (
  'Ascent' => 1123,
  'Descent' => -391,
  'CapHeight' => 717,
  'Flags' => 4,
  'FontBBox' => '[-308 -854 1513 1278]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 605,
);
$up=-278;
$ut=29;
$ttffile='D:/wamp/www/sma3/sma/libraries/MPDF/ttfonts/XB Riyaz.ttf';
$TTCfontID='0';
$originalsize=1144764;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='xbriyaz';
$panose=' 0 0 2 0 5 3 8 0 0 2 0 4';
$haskerninfo=false;
$unAGlyphs=true;
?>