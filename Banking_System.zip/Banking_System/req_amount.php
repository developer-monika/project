<?php 
include("db.php");
if(! isset($_SESSION['is_user_logged_in']))
{
	header("location:login.php");
}
include("user_header.php");

?>
<div class="content">
<div class="container" style="padding-top:50px;">
		<div style="min-height:250px; height:auto; width:700px; margin:0px auto; box-shadow:0 0 5px #ccc;border-radius:10px;">
			<h2>Request Your Amout to Administrator</h2>
			<form action="save_request.php" method="post">
				<table align="center">
					<tr>
						<td>Amount</td>
						<td><input type="Text" placeholder="Your Amount" name="v_amount" /></td>
					</tr>
					<tr>
						<td>Remark</td>
						<td><textarea name="v_remark" rows="8" cols="35"></textarea></td>
					</tr>
					<tr>
						<td><input type="submit" value="Request" /></td>
					</tr>

				</table>
			</form>
		</div>
</div>
</div>
<?php 
include "footer.php";
?>