<?php
$con=@mysql_connect("localhost", "root", "");
mysql_select_db("newdb", $con);
session_start();
// print_r($_SERVER);
?>