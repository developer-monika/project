<?php
// print_r($_SERVER);
// die;
include("db.php");
// print_r($_POST);
$u=$_POST['username'];
$p=$_POST['password'];
$p=md5($p);
$que="SELECT * FROM user_tbl WHERE email='$u'";
$obj=mysql_query($que);
// echo mysql_num_rows($obj);
if(mysql_num_rows($obj)==1)
{
	$data=mysql_fetch_assoc($obj);
	// print_r($data);
	if($data['password']==$p)
	{
		$ip_addr=$_SERVER['REMOTE_ADDR'];
		$a=$data['id'];
		$que="INSERT INTO user_track_tbl (user_id, ip_address) VALUES ($a, '$ip_addr')";
		mysql_query($que);
		//mysql_query("INSERT INTO user_track_tbl (user_id, ip_address) VALUES (".$data['id'].", '$ip_addr')");
		$_SESSION['id']=$data['id'];
		$_SESSION['name']=$data['full_name'];
		$_SESSION['account_no']=$data['account_no'];
		$_SESSION['is_user_logged_in']=true;
		header("location:dashboard.php");
	}
	else
	{
		$_SESSION['username']=$u;
		$_SESSION['msg']="This passsword is incorrect !";
		header("location:login.php");	
	}

}else{
	$_SESSION['msg']="This username and passsword incorrect !";
	header("location:login.php");
}
?>