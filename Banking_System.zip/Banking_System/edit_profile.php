<?php 
include("db.php");
if(! isset($_SESSION['is_user_logged_in']))
{
	header("location:login.php");
}
include("user_header.php");
$que="SELECT * FROM user_tbl WHERE id=".$_SESSION['id'];
$obj=mysql_query($que);
$data=mysql_fetch_assoc($obj);
// print_r($data);
?>
<div class="content">
<div class="container" style="padding-top:50px;">
		<div style="min-height:250px; height:auto; width:400px; margin:0px auto; box-shadow:0 0 5px #ccc;border-radius:10px;">
			<h2>Edit Your Profile</h2>
			<form action="update_profile.php" method="post">
			<table align="center">
				<tr>
					<td>Full Name</td>
					<td><input type="text" name="full_name" value="<?php echo $data['full_name']; ?>"/></td>
				</tr>
				<tr>
					<td>Email</td>
					<td><input type="text"  value="<?php echo $data['email']; ?>" disabled="disabled"/></td>
				</tr>
				<tr>
					<td>Account No</td>
					<td><input type="text" value="<?php echo $data['account_no']; ?>" disabled="disabled"/></td>
				</tr>
				<tr>
					<td>Balance</td>
					<td><input type="text"  value="<?php echo $data['balance']; ?>" disabled="disabled"/></td>
				</tr>
				<tr>
					<td>Contact</td>
					<td><input type="text" name="contact" value="<?php echo $data['contact']; ?>" /></td>
				</tr>
				<tr>
					<td>Gender</td>
					<td>Male<input type="radio" name="gender" value="male" <?php if($data['gender']=="male") { echo "checked='checked'"; } ?> />Female<input <?php if($data['gender']=="female") { echo "checked='checked'"; } ?> type="radio" name="gender" value="female" /></td>
				</tr>
				<tr>
					<td>City</td>
					<td><select name="city">
							<option>Select</option>
							<option <?php if($data['city']=="Indore") { echo "selected='selected'"; } ?>>Indore</option>
							<option <?php if($data['city']=="Mumbai") { echo "selected='selected'"; } ?>>Mumbai</option>
							<option <?php if($data['city']=="Bhopal") { echo "selected='selected'"; } ?>>Bhopal</option>
							<option <?php if($data['city']=="Ujjain") { echo "selected='selected'"; } ?>>Ujjain</option>
							
						</select></td>
				</tr>
				<tr>
					<td><input type="submit" value="Update" /></td>
				</tr>
			</table>
		</form>

		</div>
</div>
</div>
<?php 
include "footer.php";
?>