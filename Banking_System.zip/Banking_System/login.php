
<?php 
include("db.php");
include("header.php");

?>
<div class="content">
<div class="container" style="padding-top:50px;">
		<div style="min-height:250px; height:auto; width:400px; margin:0px auto; box-shadow:0 0 5px #ccc;border-radius:10px;">
			<h2>User Login</h2>
			<form action="auth.php" method="post">
				<table align="center">
					<tr>
						<td>Username</td>
						<td><input type="Text" placeholder="Username" name="username" value="<?php 
						if(isset($_SESSION['username']))
						{

							echo $_SESSION['username'];
							unset($_SESSION['username']);
						} ?>"/></td>
					</tr>
					<tr>
						<td>Password</td>
						<td><input type="password" placeholder="Password" name="password"/></td>
					</tr>
					<tr>
						<td><input type="submit" value="Login" /></td>
					</tr>

				</table>
				<?php
				if(isset($_SESSION['msg']))
				{

					echo "<p class='error'>".$_SESSION['msg']."</p>";
					unset($_SESSION['msg']);
				}
				?>
			</form>
		</div>
</div>
</div>
<?php 
include "footer.php";
?>