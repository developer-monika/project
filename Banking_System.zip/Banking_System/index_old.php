<!DOCTYPE html>
<html>
<head>
	<title>BANK : Welcome</title>
	<link rel=icon type=image/ico href="images/icon.png" />
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css">
</head>
<body>
<header class="header">
	<div class="container">
		<div class="logo">
			<a href="index.php"><img src="images/logo2.png" alt="Logo for the website"/></a>
		</div>
		<div class="menu">
		<a href="#" class="pull-right"><i class="fa fa-cog fa-spin fa-2x"></i></a>
			<ul>
				<li><a href="index.php"><i class="fa fa-home"></i> Home</a></li>
				<li><a href="index1.php"><i class="fa fa-info-circle"></i> About Us</a></li>
				<li><a href="#"><i class="fa fa-sign-in"></i> Login</a></li>
				<li><a href="#"><i class="fa fa-user-plus"></i> Signup</a></li>
				<li><a href="color.php"><i class="fa fa-user-plus"></i> color</a></li>
			</ul>
		</div>
	</div>
</header>
<div class="content">
	<div class="container">
		<h1 class="text-center welcome">Welcome To HDFC Online</h2>
		<p class="text-center welcome">We Understand your world  <i class="fa fa-smile-o"></i></p>
	</div>
</div>
<footer class="footer">
	<div class="container"></div>
</footer>
<div class="color-theem">
	<span style="background: #dddfd4;">#dddfd4</span>
	<span style="background: #fae596;">#fae596</span>
	<span style="background: #3fb0ac;">#3fb0ac</span>
	<span style="background: #173e43;">#173e43</span>
</div>
</body>
</html>