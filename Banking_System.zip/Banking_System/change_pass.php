<?php 
include("db.php");
if(! isset($_SESSION['is_user_logged_in']))
{
	header("location:login.php");
}
include("user_header.php");
?>
<div class="content">
<div class="container" style="padding-top:50px;">
		<div style="min-height:250px; height:auto; width:400px; margin:0px auto; box-shadow:0 0 5px #ccc;border-radius:10px;">
			<h2>Change your Password</h2>
			<form action="update_pass.php" method="post">
				<table align="center">
					<tr>
						<td>Current Password</td>
						<td><input type="password" name="c_pass"/></td>
					</tr>
					<tr>
						<td>New Password</td>
						<td><input type="password" name="n_pass"/></td>
					</tr>
					<tr>
						<td>Confirm New Password</td>
						<td><input type="password" name="cn_pass"/></td>
					</tr>
					<tr>
						<td><input type="submit" value="upload" /></td>
					</tr>
				</table>
			</form>
			<?php
			if(isset($_SESSION['msg']))
			{
				echo $_SESSION['msg'];
				unset($_SESSION['msg']);
			}
			?>
			
		</div>
</div>
</div>
<?php 
include "footer.php";
?>