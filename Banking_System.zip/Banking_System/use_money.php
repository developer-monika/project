<?php 
include("db.php");
if(! isset($_SESSION['is_user_logged_in']))
{
	header("location:login.php");
}
include("user_header.php");
$id=$_SESSION['id'];
$que="SELECT balance FROM user_tbl WHERE id=$id";
$obj=mysql_query($que);
$data=mysql_fetch_assoc($obj);
// print_r($data);
?>
<div class="content">
<div class="container" style="padding-top:50px;">
		<div style="min-height:250px; height:auto; width:700px; margin:0px auto; box-shadow:0 0 5px #ccc;border-radius:10px;">
			<h2>Use Your Amount : <?php echo $data['balance'];?></h2>
			<form action="save_money.php" method="post">
				<table align="center">
					<tr>
						<td>Amount</td>
						<td><input type="Text" placeholder="Your Amount" name="v_amount" /></td>
					</tr>
					<tr>
						<td>Purpose</td>
						<td><select name="v_purpose">
								<option>Select</option>
								<option>Recharge</option>
								<option>Ticket</option>
								<option>Some Product</option>
								<option>Donation</option>
								<option>Fee</option>
								<option>Rent</option>
						</select></td>
					</tr>
					<tr>
						<td><input type="submit" value="Buy" /></td>
					</tr>

				</table>
				<?php
				if(isset($_SESSION['msg']))
				{
					echo $_SESSION['msg'];
					unset($_SESSION['msg']);
				}
				?>
			</form>
		</div>
</div>
</div>
<?php 
include "footer.php";
?>