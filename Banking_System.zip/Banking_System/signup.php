
<?php 
include("header.php");
?>
<div class="content">
<div class="container" style="padding-top:50px;">
		<div style="min-height:250px; height:auto; width:400px; margin:0px auto; box-shadow:0 0 5px #ccc;border-radius:10px;">
			<h2>User Registration</h2>
			<form action="save.php" method="post">
				<table align="center">
					<tr>
						<td>Full Name</td>
						<td><input type="Text" placeholder="Full Name" name="full_name"/></td>
					</tr>
					<tr>
						<td>Email</td>
						<td><input type="Text" placeholder="Email" name="email"/></td>
					</tr>
					<tr>
						<td>Password</td>
						<td><input type="password" placeholder="Password" name="password"/></td>
					</tr>
					<tr>
						<td>Re-Password</td>
						<td><input type="password" placeholder="Re-Password" name="re_pass"/></td>
					</tr>
					<tr>
						<td>Opening Balance</td>
						<td><input type="text" placeholder="Opening Balance" name="ope_balance"/></td>
					</tr>
					<tr>
						<td>Contact</td>
						<td><input type="Text" placeholder="Contact" name="contact"/></td>
					</tr>
					<tr>
						<td>City</td>
						<td><select name="city">
							<option>Select</option>
							<option>Indore</option>
							<option>Mumbai</option>
							<option>Bhopal</option>
							<option>Ujjain</option>
							
						</select></td>
					</tr>
					<tr>
						<td>Gender</td>
						<td>Male<input type="radio" name="gender" value="male"/>Female<input type="radio" name="gender" value="female"/></td>
					</tr>
					<tr>
						
						<td><input type="submit" value="Signup" name="submit"/></td>
					</tr>
				</table>

			</form>
			
		</div>
</div>
</div>
<?php 
include "footer.php";
?>