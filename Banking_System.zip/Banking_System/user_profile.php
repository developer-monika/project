<?php 
include("db.php");
if(! isset($_SESSION['is_user_logged_in']))
{
	header("location:login.php");
}
include("user_header.php");
$que="SELECT * FROM user_tbl WHERE id=".$_SESSION['id'];
$obj=mysql_query($que);
$data=mysql_fetch_assoc($obj);
if($data['image_name']=="")
{

	if($data['gender']=="male")
	{
		$path="images/male.png";
	}
	if($data['gender']=="female")
	{
		$path="images/female.png";
	}
}else{
	$path="upload_image/".$data['image_name'];
}

// print_r($data);
?>
<div class="content">
<div class="container" style="padding-top:50px;">
		<div style="min-height:250px; height:auto; width:400px; margin:0px auto; box-shadow:0 0 5px #ccc;border-radius:10px;">
			<h2>My Profile</h2>
			<img src="<?php echo $path;?>" height="100" width="100" />
			<table align="center">
				<tr>
					<td>Full Name</td>
					<td><?php echo $data['full_name']; ?></td>
				</tr>
				<tr>
					<td>Email</td>
					<td><?php echo $data['email']; ?></td>
				</tr>
				<tr>
					<td>Account No</td>
					<td><?php echo $data['account_no']; ?></td>
				</tr>
				<tr>
					<td>Balance</td>
					<td><?php echo $data['balance']; ?></td>
				</tr>
				<tr>
					<td>Contact</td>
					<td><?php echo $data['contact']; ?></td>
				</tr>
				<tr>
					<td>Gender</td>
					<td><?php echo $data['gender']; ?></td>
				</tr>
				<tr>
					<td>City</td>
					<td><?php echo $data['city']; ?></td>
				</tr>
			</table>

			<a href="edit_profile.php">Edit Your Profile</a>
			<a href="select_image.php">Upload Your Profile Pic</a>
			<a href="change_pass.php">Change Pass</a>
		</div>
</div>
</div>
<?php 
include "footer.php";
?>