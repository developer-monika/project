<?php
$pagename=$_SERVER['PHP_SELF'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>BANK : Welcome</title>
	<link rel=icon type=image/ico href="images/icon.png" />
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css">
</head>
<body>
<header class="header">
	<div class="container">
		<div class="logo">
			<a href="index.php"><img src="images/logo2.png" alt="Logo for the website"/></a>
		</div>
		<div class="menu">
		<a href="#" class="pull-right"><i class="fa fa-cog fa-spin fa-2x"></i></a>
			<ul>
				<li><a href="dashboard.php" <?php if(strstr($pagename, 'dashboard.php')){ echo "class='active'"; } ?>><i class="fa fa-home"></i>Dashboard</a></li>
				<li><a href="req_amount.php" <?php if(strstr($pagename, 'req_amount.php')){ echo "class='active'"; } ?>><i class="fa fa-home"></i>Request Amount</a></li>
				<li><a href="use_money.php" <?php if(strstr($pagename, 'use_money.php')){ echo "class='active'"; } ?>><i class="fa fa-home"></i>Use Money</a></li>
				<!-- <li><a href="index1.php"><i class="fa fa-info-circle"></i> About Us</a></li> -->
				<li><a href="user_profile.php" <?php if(strstr($pagename, 'user_profile.php')){ echo "class='active'"; } ?>><i class="fa fa-sign-in"></i>My Profile</a></li>
				<li><a href="my_account.php" <?php if(strstr($pagename, 'my_account.php')){ echo "class='active'"; } ?>><i class="fa fa-user-plus"></i>My Account</a></li>
				<li><a href="logout.php"><i class="fa fa-user-plus"></i>Logout</a></li>
			</ul>
		</div>
	</div>
</header>