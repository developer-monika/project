<?php
// print_r($_POST);
include("db.php");
if(! isset($_SESSION['is_user_logged_in']))
{
	header("location:login.php");
}
$a=$_POST['v_amount'];
$b=$_POST['v_purpose'];
$id=$_SESSION['id'];
$que="SELECT balance FROM user_tbl WHERE id=$id";
$obj=mysql_query($que);
$data=mysql_fetch_assoc($obj);
if($a>$data['balance'])
{
	$_SESSION['msg']="Insufficient Balance :";
	// $_SESSION['balance']=$a;
	header("location:use_money.php");
}
else
{
	mysql_query("INSERT INTO request_amount_tbl (user_id, amount, remark, status, trans_type) VALUES ($id, $a, '$b', 1, 2)");
	mysql_query("UPDATE user_tbl SET balance=balance-$a WHERE id=$id");
	$_SESSION['msg']="Transaction Successful!";
	header("location:dashboard.php");
}

?>