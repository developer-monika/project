<?php
include("../db.php");
if(! isset($_SESSION['is_admin_logged_in']))
{
	header("location:../index.php");
}
$que="SELECT * FROM request_amount_tbl WHERE status=0";
$obj=mysql_query($que);
?>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<div id="header">
	<div id="inside-header">
		<h2>Administration Panel</h2>
		<a class="btn" href="view_all_user.php">View All User</a>
		<a  class="btn" href="view_pending_request.php">View All Request</a>
	</div>
</div>
<div id="content">
	<div id="inside-content">
		<div id="login-box">
			<h2>View All Pending Request</h2>
			<table style="font-size:14px">
				<tr>
					<th>S.No.</th>
					<th>User Id</th>
					<th>Amount</th>
					<th>Remark</th>
					<th>Date</th>
					<th>Accept</th>

				</tr>
				<?php
				$n=1;
				while($data=mysql_fetch_assoc($obj))
				{
					echo "<tr align='center'>";
					echo "<td>".$n."</td>";
					echo "<td>".$data['user_id']."</td>";
					echo "<td>".$data['amount']."</td>";
					echo "<td>".$data['remark']."</td>";
					$date=$data['c_date'];
					$arr=explode(" ", $date);
					// print_r($arr);
					echo "<td>".$arr[0]."</td>";
					echo "<td><a href='request_accept.php?id=".$data['id']."'>Accept</a></td>";
					echo "</tr>";
					$n++;
				}
				?>
				

			</table>
		</div>
	</div>
</div>
</body>
</html>