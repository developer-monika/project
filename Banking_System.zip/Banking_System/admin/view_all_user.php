<?php
include("../db.php");
if(! isset($_SESSION['is_admin_logged_in']))
{
	header("location:../index.php");
}
$que="SELECT * FROM user_tbl";
$obj=mysql_query($que);
?>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<div id="header">
	<div id="inside-header">
		<h2>Administration Panel</h2>
		<a class="btn" href="view_all_user.php">View All User</a>
		<a  class="btn" href="view_pending_request.php">View All Request</a>
	</div>
</div>
<div id="content">
	<div id="inside-content">
		<div id="login-box">
			<h2>View All User</h2>
			<table style="font-size:14px">
				<tr>
					<th>S.No.</th>
					<th>Full Name</th>
					<th>Email</th>
					<th>Account No</th>
					<th>Current Balance</th>
					<th>Contact</th>
				</tr>
				<?php
					$n=1;
					while($data=mysql_fetch_assoc($obj))
					{
						echo "<tr>";
						echo "<td>".$n."</td>";
						echo "<td>".$data['full_name']."</td>";
						echo "<td>".$data['email']."</td>";
						echo "<td>".$data['account_no']."</td>";
						echo "<td>".$data['balance']."</td>";
						echo "<td>".$data['contact']."</td>";
						echo "</tr>";
						$n++;
					}
				?>

			</table>
		</div>
	</div>
</div>
</body>
</html>