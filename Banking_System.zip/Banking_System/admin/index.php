<?php
include("../db.php");
?>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<div id="header">
	<div id="inside-header">
		<h2>Administration Panel</h2>
	</div>
</div>
<div id="content">
	<div id="inside-content">
		<div id="login-box">
			<form action="auth.php" method="post">
			<table align="center">
				<tr>
					<td>Username</td>
					<td><input type="text" class="input" name="v_username" /></td>
				</tr>
				<tr>
					<td>Password</td>
					<td><input type="password" class="input" name="v_password" /></td>
				</tr>
				<tr>
					<td colspan="2" align="center">
						<input type="submit" value="Login"/>
					</td>
				</tr>


			</table>
			</form>
			<?php
			if(isset($_SESSION['msg']))
			{
				echo $_SESSION['msg'];
				unset($_SESSION['msg']);
			}
			?>
		</div>
	</div>
</div>
</body>
</html>