<?php
echo md5("admin");
?>