<?php
include("../db.php");
if(! isset($_SESSION['is_admin_logged_in']))
{
	header("location:../index.php");
}
?>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<div id="header">
	<div id="inside-header">
		<h2>Administration Panel</h2>

		<a class="btn" href="view_all_user.php">View All User</a>
		<a  class="btn" href="view_pending_request.php">View All Request</a>
	</div>
</div>
<div id="content">
	<div id="inside-content">
		<div id="login-box">
			<h2>Welcome Admin</h2>
		</div>
	</div>
</div>
</body>
</html>