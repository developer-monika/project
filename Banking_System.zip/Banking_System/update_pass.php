<?php
include("db.php");
if(! isset($_SESSION['is_user_logged_in']))
{
	header("location:login.php");
}
// print_r($_POST);
$current_pass=$_POST['c_pass'];
$current_pass=md5($current_pass);
$new_pass=$_POST['n_pass'];
$cn_pass=$_POST['cn_pass'];
$obj=mysql_query("SELECT * FROM user_tbl WHERE id=".$_SESSION['id']);
$data=mysql_fetch_assoc($obj);
// print_r($data);
if($data['password']==$current_pass)
{
	if($new_pass==$cn_pass)
	{
		$new_pass=md5($new_pass);
		mysql_query("UPDATE user_tbl SET password='$new_pass' WHERE id=".$_SESSION['id']);
		$_SESSION['msg']="Your password is changed successfully, Pls logout.... ";
		header("location:dashboard.php");		
	}
	else
	{
		$_SESSION['msg']="Confirm password is not matched";
		header("location:change_pass.php");		
	}
}
else
{
	$_SESSION['msg']="Current password is incorrect";
	header("location:change_pass.php");
}
?>