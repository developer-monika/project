<!DOCTYPE html>
<html>
<head>
	<title>BANK : Welcome</title>
	<link rel=icon type=image/ico href="images/icon.png" />
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css">
</head>
<body>
<header class="header">
	<div class="container">
		<div class="logo">
			<a href="index.php"><img src="images/logo2.png" alt="Logo for the website"/></a>
		</div>
		<div class="menu">
		<a href="#" class="pull-right"><i class="fa fa-cog fa-spin fa-2x"></i></a>
			<ul>
				<li><a href="index.php"><i class="fa fa-home"></i> Home</a></li>
				<!-- <li><a href="index1.php"><i class="fa fa-info-circle"></i> About Us</a></li> -->
				<li><a href="login.php"><i class="fa fa-sign-in"></i> Login</a></li>
				<li><a href="signup.php"><i class="fa fa-user-plus"></i> Signup</a></li>
				<li><a href="color.php"><i class="fa fa-user-plus"></i> Color</a></li>
			</ul>
		</div>
	</div>
</header>