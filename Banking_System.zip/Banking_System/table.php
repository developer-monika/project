<html>
<head>
	<title> My first table</title>
	<link rel="stylesheet" type="text/css" href="css/tablestyle.css">
</head>
<body>
<form method="post">
Insert a number <input type="text" name ="number" />
<input type="submit" name="submit" value="display">

<table border="1">  
<caption>Table</caption>

  <?php
  
   if(isset($_POST["submit"]))
   {
      $x=$_POST["number"];
       for($i=1;$i<=10;$i++)
    { ?>
  
     
    <tr> <td> <?php echo $x; ?> </td> <td> * </td> <td> <?php echo $i;?></td><td>=</td><td> <?php echo $x*$i;?> </td>
     </tr>
    <?php
      }
    ?>	
 <?php
  }
  ?>


 </table>
</form>
</body>
</html>