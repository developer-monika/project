-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 27, 2017 at 01:48 PM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tss_6`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_tbl`
--

CREATE TABLE IF NOT EXISTS `admin_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin_tbl`
--

INSERT INTO `admin_tbl` (`id`, `username`, `password`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Table structure for table `request_amount_tbl`
--

CREATE TABLE IF NOT EXISTS `request_amount_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `remark` text NOT NULL,
  `c_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0',
  `trans_type` int(1) NOT NULL COMMENT '1 for credit and 2 for debit',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `request_amount_tbl`
--

INSERT INTO `request_amount_tbl` (`id`, `user_id`, `amount`, `remark`, `c_date`, `status`, `trans_type`) VALUES
(1, 1, 50000, 'opening balance', '2017-01-25 13:25:09', 1, 1),
(2, 1, 10000, 'for shopping', '2017-01-25 13:26:52', 1, 1),
(3, 1, 500, 'Recharge', '2017-01-25 13:30:06', 1, 2),
(4, 1, 5000, 'Rent', '2017-01-25 13:37:56', 1, 2),
(5, 2, 50000, 'opening balance', '2017-01-27 13:31:36', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_tbl`
--

CREATE TABLE IF NOT EXISTS `user_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `account_no` int(11) NOT NULL,
  `balance` int(11) NOT NULL DEFAULT '1000',
  `password` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `user_tbl`
--

INSERT INTO `user_tbl` (`id`, `full_name`, `email`, `account_no`, `balance`, `password`, `contact`, `city`, `gender`, `image_name`) VALUES
(1, 'Monica', 'monica@gmail.com', 100001, 54500, '6512bd43d9caa6e02c990b0a82652dca', '0000', 'Indore', 'female', ''),
(2, 'James Joel', 'james@gmail.com', 100002, 50000, '6512bd43d9caa6e02c990b0a82652dca', '123456', 'Mumbai', 'male', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_track_tbl`
--

CREATE TABLE IF NOT EXISTS `user_track_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `ip_address` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `user_track_tbl`
--

INSERT INTO `user_track_tbl` (`id`, `user_id`, `ip_address`, `date`) VALUES
(1, 1, '127.0.0.1', '2017-01-27 13:30:58'),
(2, 2, '127.0.0.1', '2017-01-27 13:31:41'),
(3, 1, '127.0.0.1', '2017-01-27 13:31:53'),
(4, 1, '127.0.0.1', '2017-01-27 13:36:02'),
(5, 2, '127.0.0.1', '2017-01-27 13:36:16');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
