
<?php 
include("header.php");
?>
<div class="content">
<div class="container">
		<div class="left-panal">
			<div class="profil-pic text-center">
				<img src="images/icon.png">
			</div>
			<div>
				<h4 class="text-center welcome"><i class="fa fa-user"></i> BASANT GOUR</h4>
				<h4 class="text-center welcome"><i class="fa fa-id-badge"></i> 9008871167478</h4>
				<hr / style="margin: 10px 30px;">
				<h4 class="text-center no-margin"><i class="fa fa-phone"></i> 8871167478</h4>
				<h4 class="text-center no-margin"><i class="fa fa-map-marker"></i> 122/1, LALARAM NAGAR INDORE</h4>
			</div>
		</div>
		<div class="pull-right" style="width: 800px">
			<h1 class="text-center welcome">Welcome To HDFC Online</h1>
			<p class="text-center welcome">We Understand your world  <i class="fa fa-smile-o"></i></p>
			<br />
			<p class="text-center welcome">Include Successful<i class="fa fa-smile-o"></i></p>
		</div>
</div>
</div>
<?php 
include "footer.php";
?>