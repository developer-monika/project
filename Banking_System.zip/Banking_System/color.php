
<?php 
include("header.php");
?>
<div class="content">
	<div class="container">
		<div class="color-theem">
			<span style="background: #dddfd4;">#dddfd4</span>
			<span style="background: #fae596;">#fae596</span>
			<span style="background: #3fb0ac;">#3fb0ac</span>
			<span style="background: #173e43;">#173e43</span>
			<span style="background: #ed1164;">#ed1164</span>
		</div>
	</div>
</div>
<?php 
include "footer.php";
?>
