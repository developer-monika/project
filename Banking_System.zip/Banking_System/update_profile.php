<?php
include("db.php");
// print_r($_POST);
if(! isset($_SESSION['is_user_logged_in']))
{
	header("location:login.php");
}
$a=$_POST['full_name'];
$d=$_POST['contact'];
$e=$_POST['city'];
$f=$_POST['gender'];

$que="UPDATE user_tbl SET full_name='$a', contact='$d', city='$e', gender='$f' WHERE id=".$_SESSION['id'];
mysql_query($que);
header("location:user_profile.php");

?>