<?php 
include("db.php");
if(! isset($_SESSION['is_user_logged_in']))
{
	header("location:login.php");
}
include("user_header.php");
$id=$_SESSION['id'];
$que="SELECT * FROM user_track_tbl WHERE  user_id=$id ORDER BY id DESC LIMIT 1,1";
$obj=mysql_query($que);
$data=mysql_fetch_assoc($obj);
// $arr=explode(" ", $data['date']);
// print_r($data);
?>
<div class="content">
<div class="container" style="padding-top:50px;">
		<div style="min-height:250px; height:auto; width:400px; margin:0px auto; box-shadow:0 0 5px #ccc;border-radius:10px;">
			<h2>Welcome : <?php echo $_SESSION['name'];?></h2>
			<!-- <h4>Last Login Time : <?php echo $arr[0];?></h4> -->
			<h4>Last Login Time : <?php echo $data['date'];?></h4>
			<?php
			if(isset($_SESSION['msg']))
			{
				echo $_SESSION['msg'];
				unset($_SESSION['msg']);
			}
			?>
		</div>
</div>
</div>
<?php 
include "footer.php";
?>