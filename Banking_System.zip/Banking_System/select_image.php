<?php 
include("db.php");
if(! isset($_SESSION['is_user_logged_in']))
{
	header("location:login.php");
}
include("user_header.php");
$que="SELECT * FROM user_tbl WHERE id=".$_SESSION['id'];
$obj=mysql_query($que);
$data=mysql_fetch_assoc($obj);
if($data['gender']=="male")
{
	$path="images/male.png";
}
if($data['gender']=="female")
{
	$path="images/female.png";
}

// print_r($data);
?>
<div class="content">
<div class="container" style="padding-top:50px;">
		<div style="min-height:250px; height:auto; width:400px; margin:0px auto; box-shadow:0 0 5px #ccc;border-radius:10px;">
			<h2>My Profile</h2>
			Current Image<img src="<?php echo $path;?>" height="100" width="100" />
			

			<form action="upload_image.php" method="post" enctype="multipart/form-data">
				Select Image <input type="file" name="v_image" />
				<Br />
				<input type="submit" value="upload" />
			</form>
			<?php
			if(isset($_SESSION['msg']))
			{
				echo $_SESSION['msg'];
				unset($_SESSION['msg']);
			}
			?>
		</div>
</div>
</div>
<?php 
include "footer.php";
?>