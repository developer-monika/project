<?php
include("db.php");
// print_r($_POST);
$a=$_POST['v_amount'];
$b=$_POST['v_remark'];
$id=$_SESSION['id'];
$que="INSERT INTO request_amount_tbl (user_id, amount, remark, trans_type) VALUES ($id, $a, '$b', 1)";
mysql_query($que);
$_SESSION['msg']="Your request has been added";
header("location:dashboard.php");

?>