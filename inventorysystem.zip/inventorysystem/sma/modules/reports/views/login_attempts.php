<h1>Login attempts</h1>
<script>
             $(document).ready(function() {
                $('#fileData').dataTable( {
					"aLengthMenu": [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]],
                    "aaSorting": [[ 4, "asc" ]],
                    "iDisplayLength": 10,
					"oTableTools": {
						"sSwfPath": "assets/media/swf/copy_csv_xls_pdf.swf",
						"aButtons": [
								// "copy",
								"csv",
								"xls",
								{
									"sExtends": "pdf",
									"sPdfOrientation": "landscape",
									"sPdfMessage": ""
								},
								"print"
						]
					},
					"oLanguage": {
					  "sSearch": "Filter: "
					},
					"aoColumns": [ 
					
					  null,
					  null,
					  null,
					  null,
					  null,
					  { "bSortable": false }
					]
					
                } );
				
            } );
                    
</script>
        

<?php if($message) { echo "<div class=\"alert alert-error\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $message . "</div>"; } ?>
<?php if($success_message) { echo "<div class=\"alert alert-success\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $success_message . "</div>"; } ?>


	<h3 class="title"><?php echo $this->lang->line("Login Attempts") ?></h3>
	<p class="introtext"><?php echo $this->lang->line("list_results"); ?></p>
	
	<table id="fileData" class="table table-bordered table-hover table-striped" style="margin-bottom: 5px;">
		<thead>
        <tr>
			<th><?php echo $this->lang->line("id"); ?></th>
			<th><?php echo $this->lang->line("IP Address"); ?></th>
			<th><?php echo $this->lang->line("Login"); ?></th>
			<th><?php echo $this->lang->line("Time"); ?></th>
			<!-- <th style="width:45px;"><?php echo $this->lang->line("actions"); ?></th> -->
		</tr>
        </thead>
		<tbody>
		<?php foreach ($users as $user):?>
			<tr>
				<td><?php echo $user->id;?></td>
                <td><?php echo $user->ip_address;?></td>
                <td><?php echo $user->login;?></td>
                <td><?php echo $user->time;?></td>
                <td>
					<?php foreach ($user->groups as $group):?>
						<!-- <?php echo $group->description;?> -->
	                <?php endforeach?>
				</td>
			</tr>
		<?php endforeach;?>
        </tbody>
	</table>
